You can see this project on http://cafeostap.ml/  
Such technologies are used:  
Spring_MVC,  
Spring Social,  
Spring_Security,  
Cloudinary cloud userDetailsService,  
JSP,JSTL. 

Project description:  
In this web application, admin can add, update and delete meals and their components in the database.  
A client can see the menu of meals and filter them by different parameters.    
He also can choose a table and buy some meals from the menu.  
In the main page, there are 5 top rated meals.   
After buying meal client can rate it and comment.  
Admin can change the status of order: ACCEPTED, IS BEING PREPARED, IS READY, IS PAID.  
Validation is enabled for all forms.  
There are pagination and search by the filter in all pages.  
A client can upload his photo in user cabinet.  
All photos (meals and clients) are uploaded on Cloudinary cloud userDetailsService.  
There is an ability to login using Google or Facebook account.
package ua.validation.flag;

public interface OrderFlag {

}

package ua.validation.flag;

public interface PlaceFlag {

}

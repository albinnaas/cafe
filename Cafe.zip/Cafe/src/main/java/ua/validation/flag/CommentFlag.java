package ua.validation.flag;

public interface CommentFlag {

}

package ua.validation.flag;

public interface MealFlag {

}

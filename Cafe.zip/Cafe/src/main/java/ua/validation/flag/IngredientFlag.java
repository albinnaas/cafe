package ua.validation.flag;

public interface IngredientFlag {

}

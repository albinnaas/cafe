package ua.validation.flag;

public interface ComponentFlag {

}

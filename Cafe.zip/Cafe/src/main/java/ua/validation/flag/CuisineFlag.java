package ua.validation.flag;

public interface CuisineFlag {

}

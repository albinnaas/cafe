package ua.exception;

public class CafeException extends RuntimeException {
    public CafeException(String message) {
        super(message);
    }
}

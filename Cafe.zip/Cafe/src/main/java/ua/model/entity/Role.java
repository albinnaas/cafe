package ua.model.entity;

public enum Role {

    ROLE_ADMIN, ROLE_CLIENT
}

package ua.model.entity;

public enum OrderStatus {
    MEALS_SELECTED, ACCEPTED, IS_BEING_PREPARED, IS_READY, IS_PAID
}
